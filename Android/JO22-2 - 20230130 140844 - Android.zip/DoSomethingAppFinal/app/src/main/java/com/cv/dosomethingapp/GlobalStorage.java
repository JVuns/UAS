package com.cv.dosomethingapp;

import androidx.fragment.app.Fragment;
import androidx.fragment.app.FragmentActivity;

import com.google.android.gms.maps.SupportMapFragment;

public class GlobalStorage {

    public static User user;
    public static SupportMapFragment smf;

}
