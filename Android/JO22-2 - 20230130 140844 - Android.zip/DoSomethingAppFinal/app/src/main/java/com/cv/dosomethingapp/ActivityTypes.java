package com.cv.dosomethingapp;

public class ActivityTypes {
    private String activityType;
    private String activityTypeDetail;

    public String getActivityType() {
        return activityType;
    }

    public void setActivityType(String activityType) {
        this.activityType = activityType;
    }

    public String getActivityTypeDetail() {
        return activityTypeDetail;
    }

    public void setActivityTypeDetail(String activityTypeDetail) {
        this.activityTypeDetail = activityTypeDetail;
    }
}
